import json
import struct

directions = ('top', 'right', 'bottom', 'left')


def parse_items(fname):
    def parse_scripts(parameter):
        scripts = {}
        if script_dress != '-':
            scripts['dress'] = script_dress
        if script_undress != '-':
            scripts['undress'] = script_undress
        if script_active != '-':
            scripts['active'] = script_active

        return scripts

    def parse_limit(parameter):
        data = {}
        if parameter['strength'] > 0:
            data['strength'] = parameter['strength']

        if parameter['dexterity'] > 0:
            data['dexterity'] = parameter['dexterity']

        if parameter['intelligence'] > 0:
            data['intelligence'] = parameter['intelligence']

        if parameter['sex'] is not None:
            data['sex'] = parameter['sex']

        if parameter['level'] > 0:
            data['level'] = parameter['level']

        if parameter['classes'] > 0:
            data['class'] = parameter['classes']

        if parameter['promotion'] > 0:
            data['promotion'] = parameter['promotion']

        return data

    def parse_common(parameter):
        item_types = (('weapon', None, None), ('armor', None, None), ('shield', None, None), ('helmet', None, None), ('ring', None, None), ('auxiliary', None, None), ('consume',
                                                                                                                                                                       'package', None), ('consume', 'bundle', None), ('stuff', 'default', True), ('stuff', None, False), ('stuff', None, False), ('stuff', 'bundle', False), ('arrow', None, None))

        data = {}
        data['name'] = parameter['name']
        data['icon'] = parameter['icon']
        data['color'] = parameter['color']
        data['price'] = parameter['price']
        data['entrust'] = {'enabled': True,
                           'price': parameter['price_entrust']}
        data['trade'] = {'enabled': parameter['enabled_trade']}

        if parameter['death_penalty'] is not None:
            data['death penalty'] = parameter['death_penalty']

        item_type, bundle, available = item_types[parameter['item_type']]
        data['type'] = item_type
        if bundle is not None:
            data['bundle type'] = bundle

        if available is not None:
            data['available'] = available

        capacity = parameter['capacity']
        if capacity > 0:
            if capacity == 1 and bundle is not None and bundle == 'bundle':
                del data['bundle type']
            else:
                data['capacity'] = capacity

        durability = parameter['durability']
        if durability > 0 and item_type == 'consume':
            data['capacity'] = durability

        data['limit'] = parse_limit(parameter)
        if not data['limit']:
            del data['limit']

        data['script'] = parse_scripts(parameter)
        if not data['script']:
            del data['script']

        if parameter['tooltip'] != '-':
            data['tooltip'] = parameter['tooltip']

        if parameter['desc'] != '-':
            data['desc'] = parameter['desc']

        return data

        return data

    def parse_equipment(parameter, extension):
        data = {}
        data['look'] = parameter['look']
        data['repair'] = {'enabled': parameter['enabled_repair'],
                          'price': parameter['price_repair']}
        if not data['repair']['enabled']:
            del data['repair']['price']

        data['rename'] = {'enabled': True, 'price': parameter['price_rename']}
        if not data['rename']['enabled']:
            del data['rename']['price']

        if script_dress in extension:
            extension_item = extension[script_dress]

            if all(x in extension_item for x in ['s_mindam', 's_maxdam', 'l_mindam', 'l_maxdam']):
                data['damage range'] = {'small': {'min': extension_item['s_mindam'], 'max': extension_item['s_maxdam']}, 'large': {
                    'min': extension_item['l_mindam'], 'max': extension_item['l_maxdam']}}

            defensive = {}
            if 'defensive physical' in extension_item:
                defensive['physical'] = extension_item['defensive physical']

            if 'defensive magical' in extension_item:
                defensive['magical'] = extension_item['defensive magical']
            if len(defensive) > 0:
                data['defensive'] = defensive

            if 'hit' in extension_item:
                data['hit'] = extension_item['hit']

            if 'damage' in extension_item:
                data['damage'] = extension_item['damage']

            if 'strength' in extension_item:
                data['strength'] = extension_item['strength']

            if 'intelligence' in extension_item:
                data['intelligence'] = extension_item['intelligence']

            if 'dexterity' in extension_item:
                data['dexterity'] = extension_item['dexterity']

            if 'hp' in extension_item:
                data['hp'] = extension_item['hp']

            if 'mp' in extension_item:
                data['mp'] = extension_item['mp']

            if 'swing sound' in extension_item:
                data['sound'] = extension_item['swing sound']

            if 'hp percent' in extension_item:
                data['hp percent'] = extension_item['hp percent']

            if 'mp percent' in extension_item:
                data['mp percent'] = extension_item['mp percent']

            if 'healing cycle' in extension_item:
                data['healing cycle'] = extension_item['healing cycle']

            if 'spell' in extension_item:
                data['spell'] = extension_item['spell']

        return data

    sexes = (None, 'man', 'woman')
    death_penalties = ('drop', 'destroy', None)

    items = {}
    with open(fname) as f:
        extension = None
        with open('item_db_ext.txt') as f_ext:
            extension = json.load(f_ext)

        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 27:
                continue

            index, name, item_type, icon, look, color, capacity, durability, price, strength, dexterity, intelligence, sex, level, classes, promotion, death_penalty, enabled_trade, enabled_repair, price_repair, price_entrust, price_rename, script_dress, script_undress, script_active, tooltip, desc = splitted
            parameter = {'index': int(index), 'name': name, 'item_type': int(item_type), 'icon': int(icon), 'look': int(look), 'color': int(color), 'capacity': int(capacity), 'durability': int(durability), 'price': int(price), 'strength': int(strength), 'dexterity': int(dexterity), 'intelligence': int(intelligence), 'sex': sexes[int(sex)], 'level': int(level), 'classes': int(classes), 'promotion': int(
                promotion), 'death_penalty': death_penalties[int(death_penalty)], 'enabled_trade': bool(int(enabled_trade)), 'enabled_repair': bool(int(enabled_repair)), 'price_repair': float(price_repair), 'price_entrust': int(price_entrust), 'price_rename': int(price_rename), 'script_dress': script_dress, 'script_undress': script_undress, 'script_active': script_active, 'tooltip': tooltip, 'desc': desc}
            parameter['desc'] = parameter['desc'].strip()

            # common data
            data = parse_common(parameter)
            if parameter['item_type'] < 6:
                data['equipment option'] = parse_equipment(
                    parameter, extension)
                if not data['equipment option']:
                    del data['equipment option']

            index = int(index)
            items[index] = data

    return items


def parse_maps(fname):
    def parse_map_blocks(index):
        size = {'width': 0, 'height': 0}
        blocks = []

        try:
            with open(f'../map/{index:06}.map', 'rb') as f:
                size['width'], size['height'] = struct.unpack('>hh', f.read(4))

            with open(f'../map/{index:06}.txt') as f:
                for line in f.readlines():
                    _, offset = line.split('\t')
                    offset = int(offset)
                    blocks.append({'x': offset % size['width'],
                                   'y': offset // size['width']})
        except:
            pass

        return blocks

    maps = {}
    blocks = {}
    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 6:
                continue

            index, parent, name, bgm, effect, attr = splitted
            index = int(index)
            parent = int(parent)
            bgm = int(bgm)
            effect = int(effect)
            attr = int(attr)

            maps[index] = {'name': name, 'parent': parent,
                           'bgm': int(bgm), 'option': {}}
            maps[index]['option']['build in'] = (bool(attr & 0x01))
            maps[index]['option']['enabled talk'] = not (bool(attr & 0x02))
            maps[index]['option']['enabled whisper'] = not (bool(attr & 0x04))
            maps[index]['option']['enabled magic'] = not (bool(attr & 0x08))
            maps[index]['option']['hunting ground'] = (bool(attr & 0x10))
            maps[index]['option']['enabled pk'] = (bool(attr & 0x20))
            maps[index]['option']['enabled die penalty'] = (bool(attr & 0x30))

            if effect == 0x01:
                maps[index]['effect'] = 'hot wave'
            elif effect == 0x02:
                maps[index]['effect'] = 'shipwreck'

            # blocks[index] = parse_map_blocks(index, 'block')

    return maps, blocks


def parse_npcs(fname):
    npcs = {}
    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 4:
                continue

            index, name, look, color = splitted
            index = int(index)

            npcs[index] = {'name': name, 'look': int(
                look), 'color': int(color)}

    return npcs


def parse_npc_spawn(fname, npcs, maps):
    spawns = []
    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 6:
                continue

            index, map_index, x, y, direction, script = splitted
            index = int(index)
            map_index = int(map_index)
            direction = int(direction)

            spawns.append({'npc': npcs[index]['name'], 'map': maps[map_index]['name'], 'position': {
                          'x': int(x), 'y': int(y)}, 'direction': directions[direction], 'script': script})

    return spawns


def parse_spells(fname):
    spells = {}
    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 7:
                continue

            index, name, type, cast, uncast, concast, message = splitted
            spells[index] = {'name': name, 'type': int(type)}

            if cast != '-':
                spells[index]['cast'] = cast

            if uncast != '-':
                spells[index]['uncast'] = uncast

            if concast != '-':
                spells[index]['concast'] = concast

            if message != '-':
                spells[index]['message'] = message

    return spells


def parse_mobs(fname):
    offensives = ('containment', 'counter', 'none', 'non move', 'run away')
    size_type = {'s': 'small', 'l': 'large'}
    mobs = {}

    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 15:
                continue

            index, name, look, color, hp, exp, defensive_physical, size, offensive, defensive_magical, damage_min, damage_max, script_attack, script_die, speed = splitted
            index = int(index)
            mobs[index] = {'name': name,
                           'look': int(look),
                           'color': int(color),
                           'hp': int(hp),
                           'mp': 0,
                           'size': size_type[size],
                           'experience': int(exp),
                           'defensive': {'physical': int(defensive_physical), 'magical': int(defensive_magical)},
                           'offensive': offensives[int(offensive)],
                           'damage': {'min': int(damage_min), 'max': int(damage_max)},
                           'script': {'attack': script_attack, 'die': script_die},
                           'speed': int(speed)}

            if mobs[index]['script']['attack'] == '-':
                del mobs[index]['script']['attack']

            if mobs[index]['script']['die'] == '-':
                del mobs[index]['script']['die']

            if not mobs[index]['script']:
                del mobs[index]['script']

    return mobs


def parse_mob_spawns(fname, mobs, maps):
    spawns = {}

    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) != 8:
                continue

            mob_index, map_index, x0, x1, y0, y1, count, rezen = splitted
            mob_index = int(mob_index)
            spawn = {'area': {'x0': int(x0), 'x1': int(x1), 'y0': int(y0), 'y1': int(y1)},
                     'count': int(count),
                     'name': mobs[mob_index]['name'],
                     'rezen time': int(rezen)}

            map_index = int(map_index)
            map_name = maps[map_index]['name']

            if map_name not in spawns:
                spawns[map_name] = []
            spawns[map_name].append(spawn)

    return spawns


def parse_warps(fname, maps):
    warps = {}

    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            if len(splitted) == 8:
                before_map, before_x, before_y, after_map, after_x, after_y, min_level, max_level = splitted

                before = {'map': maps[int(before_map)],
                          'position': {'x': int(before_x), 'y': int(before_y)}}
                after = {'map': maps[int(after_map)],
                         'position': {'x': int(after_x), 'y': int(after_y)}}

                map_name = before['map']['name']
                if map_name not in warps:
                    warps[map_name] = []

                warps[map_name].append({'map': after['map']['name'],
                                        'before': before['position'],
                                        'after': after['position'],
                                        'limit': {'min': int(min_level), 'max': int(max_level)}})

    return warps


if __name__ == '__main__':
    items = parse_items('item_db.txt')
    maps, blocks = parse_maps('map_db.txt')
    npcs = parse_npcs('npc_db.txt')
    npc_spawns = parse_npc_spawn('npcspawn.txt', npcs, maps)
    spells = parse_spells('spell_db.txt')
    mobs = parse_mobs('mob_db.txt')
    mob_spawns = parse_mob_spawns('mobspawn.txt', mobs, maps)
    warps = parse_warps('warp_db.txt', maps)

    with open('item.json', 'w', encoding='utf-8') as f:
        json.dump(items, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('map.json', 'w', encoding='utf-8') as f:
        json.dump(maps, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('npc.json', 'w', encoding='utf-8') as f:
        json.dump(npcs, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('npc_spawn.json', 'w', encoding='utf-8') as f:
        json.dump(npc_spawns, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('spell.json', 'w', encoding='utf-8') as f:
        json.dump(spells, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('mob.json', 'w', encoding='utf-8') as f:
        json.dump(mobs, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('mob_spawn.json', 'w', encoding='utf-8') as f:
        json.dump(mob_spawns, f, indent=4, sort_keys=False, ensure_ascii=False)

    with open('warp.json', 'w', encoding='utf-8') as f:
        json.dump(warps, f, indent=4, sort_keys=False, ensure_ascii=False)

    # for index in blocks:
    # 	with open(f'../map/{index:06}.block', 'w', encoding='utf-8') as f:
    # 		json.dump(blocks[index], f, indent=4, sort_keys=False, ensure_ascii=False)
