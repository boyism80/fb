import json
import struct


def parse_doors(fname):
    doors = []
    with open(fname) as f:
        for line in f.readlines():
            if line.startswith('//'):
                continue

            splitted = line.split('\t')
            count, splitted = int(splitted[0]), splitted[1:]

            door = []
            for pair in splitted:
                opened, closed = pair.strip().split(',')
                door.append({'open': int(opened), 'close': int(closed)})
            doors.append(door)

    return doors


doors = parse_doors('door.txt')
with open('door.json', 'w') as f:
    json.dump(doors, f, indent=4, sort_keys=False, ensure_ascii=False)
