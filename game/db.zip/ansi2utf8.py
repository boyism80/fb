import os

allowed_exts = ['.txt', '.cpp', '.h', '.hpp', '.json']
for root, dirs, files in os.walk('.'):
    for file in files:
        _, ext = os.path.splitext(file)
        if f'{ext}' not in allowed_exts:
            continue

        try:
            absolute_path = os.path.join(root, file)
            with open(absolute_path, 'r', encoding='utf-8') as f:
                lines = f.read()

            with open(absolute_path, 'w') as f:
                f.write(lines)
        except:
            continue
